# 💰 FinanceBot Pro — Consultor Financeiro com IA

> **Projeto Final — Curso de IA Generativa**  
> Chatbot especialista em finanças pessoais alimentado pela API da Anthropic (Claude Sonnet).

---

## 📋 Visão Geral

O **FinanceBot Pro** é um chatbot de IA especializado em finanças pessoais que atua como um consultor financeiro virtual. Ele ajuda os usuários a:

- 📊 Criar planos financeiros personalizados
- 💳 Eliminar dívidas com estratégias comprovadas
- 📈 Dar os primeiros passos em investimentos
- 🧠 Reformar a mentalidade sobre dinheiro
- 🏆 Alcançar a independência financeira
- 📉 Controlar gastos e montar orçamentos

**Guardrail**: Recusa educadamente qualquer pergunta fora do escopo financeiro.

---

## 🏗️ Arquitetura do Projeto

```
finance_chatbot/
│
├── chatbot.py          # 🤖 Core: cliente Anthropic + memória de conversa
├── app.py              # 🌐 Interface Web (Streamlit)
├── cli.py              # 💻 Interface Terminal (Rich)
│
├── requirements.txt    # 📦 Dependências Python
├── .env.example        # 🔑 Template de variáveis de ambiente
├── .env                # 🔑 Suas credenciais (NÃO commitar no git!)
│
├── data/               # 💾 Histórico de conversas (JSON)
│   └── conversation_history.json
│
└── logs/               # 📝 Logs de interações
    └── chat_YYYY-MM-DD.log
```

---

## ⚙️ Tecnologias Utilizadas

| Tecnologia | Uso |
|---|---|
| **Python 3.10+** | Linguagem principal |
| **Anthropic SDK** | Comunicação com Claude Sonnet |
| **Streamlit** | Interface web interativa |
| **Rich** | Interface CLI colorida e rica |
| **python-dotenv** | Gerenciamento de variáveis de ambiente |
| **JSON** | Persistência do histórico de conversa |
| **logging** | Log de todas as interações |

---

## 🚀 Instalação e Configuração

### 1. Clone ou baixe o projeto
```bash
# Se tiver git:
git clone <repo-url>
cd finance_chatbot

# Ou apenas entre na pasta do projeto
cd finance_chatbot
```

### 2. Crie um ambiente virtual (recomendado)
```bash
python -m venv venv

# Linux/Mac:
source venv/bin/activate

# Windows:
venv\Scripts\activate
```

### 3. Instale as dependências
```bash
pip install -r requirements.txt
```

### 4. Configure a API Key
```bash
# Copie o arquivo de exemplo
cp .env.example .env

# Edite o .env e adicione sua chave:
# ANTHROPIC_API_KEY=sk-ant-sua-chave-aqui
```

> 🔑 Obtenha sua API Key gratuita em: https://console.anthropic.com

---

## ▶️ Como Executar

### Interface Web (Streamlit) — Recomendado
```bash
streamlit run app.py
```
Acesse: http://localhost:8501

### Interface Terminal (CLI)
```bash
python cli.py
```

---

## 💬 Exemplos de Uso

### Orçamento
```
Você: Ganho R$ 3.500 por mês e gasto R$ 800 de aluguel. Me ajuda a criar um orçamento.
Bot: [Cria orçamento detalhado com a regra 50/30/20 personalizado]
```

### Dívidas
```
Você: Tenho R$ 8.000 no cartão de crédito e R$ 3.000 de empréstimo pessoal. O que faço?
Bot: [Estratégia bola de neve ou avalanche com cálculos reais]
```

### Investimentos
```
Você: Tenho R$ 500 para investir por mês. Onde começo?
Bot: [Plano de investimento por perfil e prazo]
```

### Fora do escopo (guardrail)
```
Você: Me conta sobre a Copa do Mundo.
Bot: Esse tema está fora da minha área 😊. Posso ajudar com finanças...
```

---

## 🔧 Funcionalidades Técnicas

### Memória de Conversa (Buffer Local)
- Mantém as últimas **20 mensagens** em memória (sliding window)
- Persiste em `data/conversation_history.json`
- Continua a conversa entre sessões

### Logging
- Todas as interações são registradas em `logs/chat_YYYY-MM-DD.log`
- Logs rotativos por dia

### Guardrails
- System prompt com instruções estritas de escopo
- Respostas educadas ao receber perguntas fora de finanças

### Tratamento de Erros
- Erros de conexão, autenticação e rate limit tratados com mensagens amigáveis
- Histórico protegido em caso de falha na API

---

## 📚 Conceitos de IA Generativa Aplicados

1. **Prompt Engineering**: System prompt detalhado com persona, regras e exemplos
2. **Conversation Memory**: Buffer de histórico para contexto multi-turno
3. **Guardrails**: Restrições de escopo via instruções no system prompt
4. **Temperature/Parameters**: Controle de criatividade e tamanho da resposta
5. **Error Handling**: Tratamento robusto de falhas da API
6. **Logging**: Rastreabilidade de todas as interações

---

## ⚠️ Aviso Legal

Este chatbot é uma ferramenta educacional. As orientações fornecidas são de caráter informativo e não substituem a consultoria de um profissional certificado (CFP). Sempre consulte um assessor financeiro para decisões importantes.

---

## 📄 Licença

Projeto educacional — Curso de IA Generativa.
