"""
╔══════════════════════════════════════════════════════════════╗
║          CONSULTOR FINANCEIRO IA - FinanceBot Pro            ║
║          Projeto Final - Curso de IA Generativa              ║
╚══════════════════════════════════════════════════════════════╝

Descrição:
    Chatbot especialista em finanças pessoais alimentado pela API da Anthropic.
    Funciona como consultor financeiro virtual capaz de ajudar com:
    - Criação de planos financeiros personalizados
    - Redução e eliminação de dívidas
    - Reforma de mentalidade sobre dinheiro
    - Investimentos e poupança
    - Orçamento mensal e controle de gastos

Autor: Projeto Final IA Generativa
Versão: 1.0.0
"""

import os
import json
import datetime
import logging
from pathlib import Path
from typing import Optional
import anthropic

# ─────────────────────────────────────────────
# CONFIGURAÇÃO DE LOGGING
# ─────────────────────────────────────────────
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / f"chat_{datetime.date.today()}.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("FinanceBot")


# ─────────────────────────────────────────────
# CONSTANTES E CONFIGURAÇÕES
# ─────────────────────────────────────────────
MODEL = "claude-sonnet-4-20250514"
MAX_TOKENS = 1500
MAX_HISTORY = 20       # número máximo de mensagens no buffer de memória
HISTORY_FILE = Path("data/conversation_history.json")


# ─────────────────────────────────────────────
# SYSTEM PROMPT - PERSONALIDADE DO BOT
# ─────────────────────────────────────────────
SYSTEM_PROMPT = """Você é o FinanceBot Pro, um consultor financeiro pessoal altamente especializado e empático. Seu objetivo é transformar a vida financeira das pessoas de forma prática e humana.

## SUA ESPECIALIDADE
Você domina profundamente:
- **Planejamento financeiro pessoal**: criação de orçamentos, metas de curto/médio/longo prazo
- **Eliminação de dívidas**: métodos bola de neve, avalanche, negociação com credores
- **Investimentos**: renda fixa (Tesouro Direto, CDB, LCI/LCA), renda variável (ações, FIIs), previdência privada
- **Mentalidade financeira**: educação sobre comportamento com dinheiro, armadilhas psicológicas, vieses cognitivos
- **Renda extra**: estratégias para aumentar receita, empreendedorismo, freelance
- **Aposentadoria e independência financeira**: FIRE, regra dos 4%, cálculo de patrimônio necessário
- **Impostos e declaração IR**: orientações gerais sobre tributação de investimentos

## SEU ESTILO DE COMUNICAÇÃO
- Use linguagem clara, acolhedora e motivadora — sem jargões desnecessários
- Seja empático: muitas pessoas têm vergonha de falar sobre dívidas; crie um ambiente seguro
- Use dados concretos, cálculos e exemplos numéricos sempre que possível
- Dê sempre um próximo passo prático e acionável ao final de cada resposta
- Use emojis moderadamente para tornar a conversa mais leve (💰📊💡)
- Quando relevante, use tabelas ou listas formatadas em Markdown

## REGRAS ABSOLUTAS — GUARDRAILS
🚫 RECUSE com educação e firmeza qualquer pergunta fora do escopo financeiro:
   - Saúde, medicina, direito, tecnologia (exceto fintech), relacionamentos, política, entretenimento, etc.
   - Ao recusar, seja gentil e redirecione o usuário para o tema financeiro.

✅ Foque EXCLUSIVAMENTE em:
   - Finanças pessoais, investimentos, orçamento, dívidas, renda, aposentadoria
   - Psicologia e comportamento financeiro
   - Educação financeira e literacia monetária

## RESPOSTA PARA ASSUNTOS FORA DO ESCOPO
Quando alguém perguntar algo fora de finanças, responda assim (adaptando naturalmente):
"Esse tema está fora da minha área de especialização 😊. Sou focado exclusivamente em finanças pessoais e posso te ajudar muito melhor com questões sobre [sugira um tema financeiro relevante]. Tem algo financeiro em que posso te ajudar?"

## QUANDO PEDIR INFORMAÇÕES
Se o usuário pedir um plano financeiro ou ajuda com orçamento sem dar dados, pergunte:
1. Renda mensal líquida
2. Gastos fixos principais (aluguel, financiamentos, etc.)
3. Dívidas existentes (valor e taxas)
4. Objetivo principal (sair das dívidas, investir, comprar imóvel, etc.)

Nunca invente números — peça os dados reais para dar conselhos precisos.

## DISCLAIMER
Sempre que recomendar investimentos específicos, inclua:
⚠️ *"Esta é uma orientação educacional. Para decisões de investimento, consulte um assessor financeiro certificado (CFP)."*
"""


# ─────────────────────────────────────────────
# GERENCIADOR DE HISTÓRICO (MEMÓRIA LOCAL)
# ─────────────────────────────────────────────
class ConversationMemory:
    """
    Gerencia o histórico da conversa com buffer local.
    Persiste as últimas N mensagens em arquivo JSON para
    continuidade entre sessões.
    """

    def __init__(self, max_messages: int = MAX_HISTORY):
        self.max_messages = max_messages
        self.messages: list[dict] = []
        self._load_history()

    def _load_history(self) -> None:
        """Carrega histórico do arquivo JSON se existir."""
        HISTORY_FILE.parent.mkdir(exist_ok=True)
        if HISTORY_FILE.exists():
            try:
                with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.messages = data.get("messages", [])
                logger.info(f"Histórico carregado: {len(self.messages)} mensagens")
            except (json.JSONDecodeError, KeyError):
                logger.warning("Histórico corrompido — iniciando novo.")
                self.messages = []

    def save_history(self) -> None:
        """Persiste o histórico atual no arquivo JSON."""
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "saved_at": datetime.datetime.now().isoformat(),
                    "messages": self.messages,
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

    def add_message(self, role: str, content: str) -> None:
        """
        Adiciona uma mensagem ao histórico.

        Args:
            role: "user" ou "assistant"
            content: texto da mensagem
        """
        self.messages.append({"role": role, "content": content})
        # Mantém apenas as últimas N mensagens (sliding window)
        if len(self.messages) > self.max_messages:
            self.messages = self.messages[-self.max_messages :]
        self.save_history()

    def get_messages(self) -> list[dict]:
        """Retorna o histórico formatado para a API da Anthropic."""
        return self.messages

    def clear(self) -> None:
        """Limpa todo o histórico da conversa."""
        self.messages = []
        if HISTORY_FILE.exists():
            HISTORY_FILE.unlink()
        logger.info("Histórico limpo.")


# ─────────────────────────────────────────────
# CLIENTE DA API ANTHROPIC
# ─────────────────────────────────────────────
class FinanceBotClient:
    """
    Cliente principal que gerencia a comunicação com a API Anthropic.
    Encapsula toda a lógica de envio/recebimento de mensagens.
    """

    def __init__(self, api_key: Optional[str] = None):
        """
        Inicializa o cliente Anthropic.

        Args:
            api_key: chave da API. Se None, usa a variável de ambiente ANTHROPIC_API_KEY.
        """
        key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise ValueError(
                "❌ API Key não encontrada!\n"
                "Configure a variável de ambiente: export ANTHROPIC_API_KEY='sua-chave'\n"
                "Ou crie um arquivo .env com ANTHROPIC_API_KEY=sua-chave"
            )
        self.client = anthropic.Anthropic(api_key=key)
        self.memory = ConversationMemory()
        logger.info("FinanceBotClient inicializado com sucesso.")

    def chat(self, user_message: str) -> str:
        """
        Envia uma mensagem e retorna a resposta do assistente.

        Args:
            user_message: mensagem do usuário

        Returns:
            Resposta do modelo como string
        """
        # Registra a mensagem do usuário
        logger.info(f"USER: {user_message[:100]}...")
        self.memory.add_message("user", user_message)

        try:
            response = self.client.messages.create(
                model=MODEL,
                max_tokens=MAX_TOKENS,
                system=SYSTEM_PROMPT,
                messages=self.memory.get_messages(),
            )

            assistant_reply = response.content[0].text

            # Registra a resposta
            logger.info(f"ASSISTANT: {assistant_reply[:100]}...")
            self.memory.add_message("assistant", assistant_reply)

            return assistant_reply

        except anthropic.APIConnectionError:
            error_msg = "❌ Erro de conexão com a API. Verifique sua internet."
            logger.error(error_msg)
            # Remove a mensagem do usuário que falhou
            self.memory.messages.pop()
            return error_msg

        except anthropic.AuthenticationError:
            error_msg = "❌ API Key inválida. Verifique suas credenciais."
            logger.error(error_msg)
            self.memory.messages.pop()
            return error_msg

        except anthropic.RateLimitError:
            error_msg = "⚠️ Limite de requisições atingido. Aguarde alguns segundos e tente novamente."
            logger.warning(error_msg)
            self.memory.messages.pop()
            return error_msg

        except Exception as e:
            error_msg = f"❌ Erro inesperado: {str(e)}"
            logger.error(error_msg, exc_info=True)
            self.memory.messages.pop()
            return error_msg

    def clear_history(self) -> None:
        """Limpa o histórico da conversa."""
        self.memory.clear()
