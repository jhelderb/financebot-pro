"""
╔══════════════════════════════════════════════════════════════╗
║          CONSULTOR FINANCEIRO IA - FinanceBot Pro            ║
║          Projeto Final - Curso de IA Generativa              ║
║          Motor: Google Gemini 2.0 Flash (FREE)               ║
╚══════════════════════════════════════════════════════════════╝

Descrição:
    Chatbot especialista em finanças pessoais alimentado pela API
    gratuita do Google Gemini (AI Studio).
    Funciona como consultor financeiro virtual capaz de ajudar com:
    - Criação de planos financeiros personalizados
    - Redução e eliminação de dívidas
    - Reforma de mentalidade sobre dinheiro
    - Investimentos e poupança
    - Orçamento mensal e controle de gastos

Autor: Projeto Final IA Generativa
Versão: 2.0.0 — Google Gemini Edition
"""

import os
import json
import datetime
import logging
from pathlib import Path
from typing import Optional

import google.generativeai as genai
from google.generativeai.types import HarmCategory, HarmBlockThreshold

# ─────────────────────────────────────────────
# CONFIGURAÇÃO DE LOGGING
# ─────────────────────────────────────────────
LOG_DIR = Path("logs")
LOG_DIR.mkdir(exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(
            LOG_DIR / f"chat_{datetime.date.today()}.log", encoding="utf-8"
        ),
    ],
)
logger = logging.getLogger("FinanceBot")


# ─────────────────────────────────────────────
# CONSTANTES E CONFIGURAÇÕES
# ─────────────────────────────────────────────
# Modelo gratuito mais capaz do Gemini (abril/2026)
MODEL = "gemini-2.0-flash"

MAX_HISTORY = 20        # número máximo de pares de mensagens no buffer
HISTORY_FILE = Path("data/conversation_history.json")


# ─────────────────────────────────────────────
# SYSTEM PROMPT — PERSONALIDADE DO BOT
# ─────────────────────────────────────────────
SYSTEM_PROMPT = """Você é o FinanceBot Pro, um consultor financeiro pessoal altamente especializado e empático. Seu objetivo é transformar a vida financeira das pessoas de forma prática e humana.

## SUA ESPECIALIDADE
Você domina profundamente:
- **Planejamento financeiro pessoal**: criação de orçamentos, metas de curto/médio/longo prazo
- **Eliminação de dívidas**: métodos bola de neve, avalanche, negociação com credores
- **Investimentos**: renda fixa (Tesouro Direto, CDB, LCI/LCA), renda variável (ações, FIIs), previdência privada
- **Mentalidade financeira**: educação sobre comportamento com dinheiro, armadilhas psicológicas, vieses cognitivos
- **Renda extra**: estratégias para aumentar receita, empreendedorismo, freelance
- **Aposentadoria e independência financeira**: FIRE, regra dos 4%, cálculo de patrimônio necessário
- **Impostos e declaração IR**: orientações gerais sobre tributação de investimentos

## SEU ESTILO DE COMUNICAÇÃO
- Use linguagem clara, acolhedora e motivadora — sem jargões desnecessários
- Seja empático: muitas pessoas têm vergonha de falar sobre dívidas; crie um ambiente seguro
- Use dados concretos, cálculos e exemplos numéricos sempre que possível
- Dê sempre um próximo passo prático e acionável ao final de cada resposta
- Use emojis moderadamente para tornar a conversa mais leve (💰📊💡)
- Quando relevante, use tabelas ou listas formatadas em Markdown

## REGRAS ABSOLUTAS — GUARDRAILS
🚫 RECUSE com educação e firmeza qualquer pergunta fora do escopo financeiro:
   - Saúde, medicina, direito, tecnologia (exceto fintech), relacionamentos, política, entretenimento, etc.
   - Ao recusar, seja gentil e redirecione o usuário para o tema financeiro.

✅ Foque EXCLUSIVAMENTE em:
   - Finanças pessoais, investimentos, orçamento, dívidas, renda, aposentadoria
   - Psicologia e comportamento financeiro
   - Educação financeira e literacia monetária

## RESPOSTA PARA ASSUNTOS FORA DO ESCOPO
Quando alguém perguntar algo fora de finanças, responda assim (adaptando naturalmente):
"Esse tema está fora da minha área de especialização 😊. Sou focado exclusivamente em finanças pessoais e posso te ajudar muito melhor com questões sobre [sugira um tema financeiro relevante]. Tem algo financeiro em que posso te ajudar?"

## QUANDO PEDIR INFORMAÇÕES
Se o usuário pedir um plano financeiro ou ajuda com orçamento sem dar dados, pergunte:
1. Renda mensal líquida
2. Gastos fixos principais (aluguel, financiamentos, etc.)
3. Dívidas existentes (valor e taxas)
4. Objetivo principal (sair das dívidas, investir, comprar imóvel, etc.)

Nunca invente números — peça os dados reais para dar conselhos precisos.

## DISCLAIMER
Sempre que recomendar investimentos específicos, inclua:
⚠️ *"Esta é uma orientação educacional. Para decisões de investimento, consulte um assessor financeiro certificado (CFP)."*
"""


# ─────────────────────────────────────────────
# GERENCIADOR DE HISTÓRICO (MEMÓRIA LOCAL)
# ─────────────────────────────────────────────
class ConversationMemory:
    """
    Gerencia o histórico da conversa com buffer local.
    Persiste as últimas N mensagens em arquivo JSON para
    continuidade entre sessões.

    O formato do histórico segue o padrão da SDK do Gemini:
        [{"role": "user", "parts": [{"text": "..."}]},
         {"role": "model", "parts": [{"text": "..."}]}, ...]
    """

    def __init__(self, max_messages: int = MAX_HISTORY):
        self.max_messages = max_messages  # número de PARES (user+model)
        self.messages: list[dict] = []
        self._load_history()

    def _load_history(self) -> None:
        """Carrega histórico do arquivo JSON se existir."""
        HISTORY_FILE.parent.mkdir(exist_ok=True)
        if HISTORY_FILE.exists():
            try:
                with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.messages = data.get("messages", [])
                logger.info(f"Histórico carregado: {len(self.messages)} mensagens")
            except (json.JSONDecodeError, KeyError):
                logger.warning("Histórico corrompido — iniciando novo.")
                self.messages = []

    def save_history(self) -> None:
        """Persiste o histórico atual no arquivo JSON."""
        with open(HISTORY_FILE, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "saved_at": datetime.datetime.now().isoformat(),
                    "messages": self.messages,
                },
                f,
                ensure_ascii=False,
                indent=2,
            )

    def add_message(self, role: str, content: str) -> None:
        """
        Adiciona uma mensagem ao histórico.

        Args:
            role: "user" ou "model"  ← Gemini usa "model" (não "assistant")
            content: texto da mensagem
        """
        # Formato nativo do Gemini
        self.messages.append({"role": role, "parts": [{"text": content}]})

        # Mantém sliding window: limita em pares (user+model)
        max_entries = self.max_messages * 2
        if len(self.messages) > max_entries:
            self.messages = self.messages[-max_entries:]

        self.save_history()

    def get_history(self) -> list[dict]:
        """
        Retorna o histórico formatado para a SDK do Gemini.
        Exclui a última mensagem do usuário (enviada separadamente).
        """
        # O Gemini recebe o histórico ANTERIOR e a mensagem atual separada
        return self.messages[:-1] if self.messages else []

    def get_last_user_message(self) -> str:
        """Retorna o texto da última mensagem do usuário."""
        if self.messages and self.messages[-1]["role"] == "user":
            return self.messages[-1]["parts"][0]["text"]
        return ""

    def clear(self) -> None:
        """Limpa todo o histórico da conversa."""
        self.messages = []
        if HISTORY_FILE.exists():
            HISTORY_FILE.unlink()
        logger.info("Histórico limpo.")


# ─────────────────────────────────────────────
# CLIENTE DA API GOOGLE GEMINI
# ─────────────────────────────────────────────
class FinanceBotClient:
    """
    Cliente principal que gerencia a comunicação com a API Google Gemini.
    Encapsula toda a lógica de envio/recebimento de mensagens com
    suporte a histórico multi-turno.
    """

    def __init__(self, api_key: Optional[str] = None):
        """
        Inicializa o cliente Gemini.

        Args:
            api_key: chave da API. Se None, usa GEMINI_API_KEY do ambiente.
        """
        key = api_key or os.environ.get("GEMINI_API_KEY")
        if not key:
            raise ValueError(
                "❌ API Key não encontrada!\n"
                "Configure a variável de ambiente: export GEMINI_API_KEY='sua-chave'\n"
                "Ou crie um arquivo .env com GEMINI_API_KEY=sua-chave\n"
                "Obtenha sua chave GRÁTIS em: https://aistudio.google.com/app/apikey"
            )

        # Configura a SDK do Gemini com a chave
        genai.configure(api_key=key)

        # Configuração de geração de texto
        self._generation_config = genai.types.GenerationConfig(
            max_output_tokens=1500,
            temperature=0.7,          # equilíbrio entre criatividade e precisão
            top_p=0.9,
        )

        # Safety settings — permissivos para conteúdo financeiro legítimo
        # (evita bloqueios indevidos em tópicos como dívidas, falências, etc.)
        self._safety_settings = {
            HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_ONLY_HIGH,
            HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_ONLY_HIGH,
            HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_ONLY_HIGH,
            HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_ONLY_HIGH,
        }

        # Instancia o modelo com o system prompt
        self._model = genai.GenerativeModel(
            model_name=MODEL,
            generation_config=self._generation_config,
            safety_settings=self._safety_settings,
            system_instruction=SYSTEM_PROMPT,
        )

        self.memory = ConversationMemory()
        logger.info(f"FinanceBotClient (Gemini) inicializado — modelo: {MODEL}")

    def chat(self, user_message: str) -> str:
        """
        Envia uma mensagem e retorna a resposta do assistente.

        Args:
            user_message: mensagem do usuário

        Returns:
            Resposta do modelo como string
        """
        logger.info(f"USER: {user_message[:100]}...")

        # Adiciona mensagem do usuário à memória
        self.memory.add_message("user", user_message)

        try:
            # Cria uma sessão de chat com o histórico anterior
            chat_session = self._model.start_chat(
                history=self.memory.get_history()
            )

            # Envia a mensagem atual
            response = chat_session.send_message(user_message)
            assistant_reply = response.text

            # Registra e persiste a resposta
            logger.info(f"ASSISTANT: {assistant_reply[:100]}...")
            self.memory.add_message("model", assistant_reply)

            return assistant_reply

        except Exception as e:
            error_str = str(e)
            logger.error(f"Erro na API Gemini: {error_str}", exc_info=True)

            # Remove a mensagem do usuário que falhou para não corromper histórico
            if self.memory.messages and self.memory.messages[-1]["role"] == "user":
                self.memory.messages.pop()

            # Mensagens de erro amigáveis baseadas no tipo de problema
            if "API_KEY_INVALID" in error_str or "API key not valid" in error_str:
                return "❌ API Key inválida. Verifique sua chave em aistudio.google.com"
            elif "quota" in error_str.lower() or "429" in error_str:
                return "⚠️ Limite de requisições atingido. Aguarde alguns segundos e tente novamente."
            elif "blocked" in error_str.lower():
                return "⚠️ Resposta bloqueada pelo filtro de segurança. Reformule sua pergunta."
            elif "connect" in error_str.lower() or "timeout" in error_str.lower():
                return "❌ Erro de conexão com a API. Verifique sua internet."
            else:
                return f"❌ Erro inesperado: {error_str}"

    def clear_history(self) -> None:
        """Limpa o histórico da conversa."""
        self.memory.clear()
